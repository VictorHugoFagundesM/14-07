"use strict";

$(function() {

    $('body.page-test').each(function() {

        var $self = $(this);

        var $div = $self.find('.div-2 > .btn:last-child');

        
        console.log($div);

    });


    var $formPrincipal = $("form#principal");
    var $formSecundario = $("form#secundario");
    var $corSelecionada = $formPrincipal.find('[name="cor"]:checked').val();
    var temCor = false;

    $formPrincipal.find(".btn-text-color").on('click', function() {
        
        var $btn = $(this);
        var classType = $btn.attr('data-class');
       
        var $text = $formPrincipal.find('#texto-lorem-ipsum');
        $text.removeClass();

        if ($btn.hasClass('enabled')) {

            $btn.find('span').text('Adicionar');
            $btn.removeClass('enabled');

        } else {

            $btn.find('span').text('Remover');
            $btn.addClass('enabled');   
            $text.addClass('text-'+classType);

            $btn.siblings().each(function($k, $b) {

                var $b = $(this);                
                $b.find('span').text('Adicionar');
                $b.removeClass('enabled');

            });

        }

    });
   
    var mudarBgColorCallback = function() {   
        
        // Obter valor do radio que está "checked"
        var codigoCorSelecionada = $formPrincipal.find('[name="cor"]:checked').val();
               
        if(temCor == true){
            var codigoCorSelecionada = "";
        }        

        console.log(`mudando cor para`, codigoCorSelecionada);
        // Setar "background-color" no form principal
        $formPrincipal.css("background-color", codigoCorSelecionada);   
        $formPrincipal.find('[name="texto_livre"]').css("color", codigoCorSelecionada);   
    };

    //Limpa a cor do background
    var $btnCleanValues = $formPrincipal.find(".btn-clean-values");

    $btnCleanValues.on("click", function() { 
        temCor = true;
        mudarBgColorCallback();
        temCor = false;
    });



 

    // dados[0].valor // blue
    // dadosObjeto.cor; // blue;


    //Mostra todos os valores
    var $btnLerValores = $formPrincipal.find(".btn-ler-valores");
    $btnLerValores.on("click",function() {

        var pessoa = {
            "nome": "Victor",
            "idade": 25,
            "sexo": "m",
        };

        var objeto1 = { "chave": "texto_livre", "valor": "bla bla bla" };
    
        var dados = [
            { "chave": "cor", "valor": "blue" },
            objeto1,
            { "chave": "pokemon", "valor": 100 },
            { "chave": "rede_social", "valor": [1, 2] },
        ];
    
        var dadosObjeto = {
            "cor": "blue",
            "texto_livre": "bla bla bla",
            "pokemon": 100,
            "rede_social": [1]
        };

        console.log(dados);


        var valoresLista = [];
        var valoresObjeto = {


        };

        var $campoCor = $formPrincipal.find(`[name="cor"]:checked`);  
        var $campoTextoLivre = $formPrincipal.find(`[name="texto_livre"]`);        
        var $campoRedeSocial = $formPrincipal.find(`[name="rede_social"]:checked`);

        var cores = { };

        var valoresLista = [
                   
        ];
        console.log(valoresLista);


 
        // $formPrincipal.find(`[name="cor"],[name="texto_livre"]`).each(function() {
        //     var $campo = $(this);
        //     var $label = $campo.closest(".form-check").find("label");
        //     var label = $label.text();
        //     var nome = $campo.attr("name");
        //     var valor = $campo.val();
        //     console.log(nome, label, valor);
        // });   

    });



    // Bind dinâmico
    $formPrincipal.on("change", '[name="cor"]', mudarBgColorCallback);

    /* $("#alterarBgColor").on("click", mudarBgColorCallback); */

    //Adiciona novas cores    
    var $btnAddCor = $formSecundario.find(".btn-add-cor");    
    
    $btnAddCor.on("click", function() {
        
        var codigo = $formSecundario.find('[name="codigo_cor"]').val();
        var nome = $formSecundario.find('[name="nome_cor"]').val();
        
        var html = `
        <div class="form-check">
            <input class="form-check-input" type="radio" name="cor" id="cor-${codigo}" value="${codigo}">
            <label class="form-check-label" for="cor-${codigo}">${nome}</label>
        </div>`;

        $formPrincipal.find(".form-group-cor").append(html);

    });

    //Adiciona novos pokemons
    var $btnAddPoke = $formSecundario.find(".btn-add-poke");

    $btnAddPoke.on("click", function() {        
        var codigoPoke = $formSecundario.find('[name="codigo_pokemon"]').val();
        var nomePoke = $formSecundario.find('[name="nome_pokemon"]').val();        
        var html = `<option value="${codigoPoke}">${nomePoke}</option>`;
        $formPrincipal.find(".form-group-poke").append(html);
    });

});